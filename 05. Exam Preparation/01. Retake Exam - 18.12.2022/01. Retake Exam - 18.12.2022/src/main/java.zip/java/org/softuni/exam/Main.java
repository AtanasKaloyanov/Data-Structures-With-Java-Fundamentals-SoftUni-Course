package org.softuni.exam;

public class Main {
    public static void main(String[] args) {
    }
}
